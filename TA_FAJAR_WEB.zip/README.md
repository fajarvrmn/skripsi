sensor ie te menang
