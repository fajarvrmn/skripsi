<div id="view_data" class="container" style="display: none;">
    <p id="message" class=""></p>
    <div class="row">
        <div class="col-lg-12">
            <div class="box">
                <div class="box-header with-border">
                    
                </div>
                <div class="box-body table-responsive">
                    <table class="table table-stiped table-bordered rounded-xl">
                        <thead>
                            <th width="5%">No</th>
                            <th>Kode</th>
                            <th>Kategori</th>
                            <th>Nama</th>
                            <th>Stok</th>
                            <th>Harga Beli</th>
                        </thead>
                        <tbody id="row-stok">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>