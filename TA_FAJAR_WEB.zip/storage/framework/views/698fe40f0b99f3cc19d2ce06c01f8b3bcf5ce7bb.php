

<?php $__env->startSection('title'); ?>
    Daftar Penggajian
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/AdminLTE-2/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="active">Penggajian</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border">
                <div class="row">
                    <?php if(auth()->user()->level == 1): ?>
                    <div class="col-md-4">
                        <label for="">Filter Berdasarkan Pegawai</label>
                        <select name="assigne" id="pegawai" class="form-control">
                            <option value="">Semua Pegawai</option>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($assigne->id); ?>"><?php echo e($assigne->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="col-md-8">
                        <div class="row align-items-center">
                            <div class="col-md-4">
                                <label for="">Tanggal Selesai Awal</label>
                                <input type="text" name="tanggal_awal" id="tanggal_awal" class="form-control datepicker" style="border-radius: 0 !important" value="<?php echo e(request('tanggal_awal')); ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label for="">Tanggal Selesai Akhir</label>
                                <input type="text" name="tanggal_akhir" id="tanggal_akhir" class="form-control datepicker" style="border-radius: 0 !important" value="<?php echo e(request('tanggal_akhir')); ?>" required>
                            </div>
                            <div class="col-md-4" style="padding-top: 25px">
                                <button type="button" class="btn btn-primary" id="filter-btn">Filter</button>
                                <form action="<?php echo e(route('gaji.cetak')); ?>" style="display: inline" method="post">
                                    <?php echo csrf_field(); ?>
                                    <select name="assigne" id="_pegawai" hidden>
                                        <option value="">Semua Pegawai</option>
                                        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($assigne->id); ?>"><?php echo e($assigne->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="hidden" name="tanggal_awal" id="_tanggal_awal" value="">
                                    <input type="hidden" name="tanggal_akhir" id="_tanggal_akhir" value="">
                                    <button type="submit" class="btn btn-success" id="cetak" <?php echo e(auth()->user()->level == 1 ? 'disabled' : ''); ?>>Cetak PDF</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-body table-responsive">
                <table class="table table-stiped table-bordered">
                    <thead>
                        <th width="5%">No</th>
                        <th>Kode PO</th>
                        <th>Pegawai</th>
                        <th>Tanggal Selesai</th>
                        <th>Harga Satuan</th>
                        <th>Bonus Satuan</th>
                        <th>Total Satuan</th>
                        
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($__env->exists('listpo.form')) echo $__env->make('listpo.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/AdminLTE-2/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<script>
    let table;

    $(function () {
        table = $('.table').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            autoWidth: false,
            ajax: {
                url: '<?php echo e(route('gaji.data')); ?>',
                data: function (d) {
                    d.assigne = $('select[name=assigne]').val();
                    d.tanggal_awal = $('input[name=tanggal_awal]').val();
                    d.tanggal_akhir = $('input[name=tanggal_akhir]').val();
                }
            },
            columns: [
                {data: 'DT_RowIndex', searchable: false, sortable: false},
                {data: 'kode'},
                {data: 'pegawai'},
                {data: 'po_selesai'},
                {data: 'harga'},
                {data: 'bonus'},
                {data: 'total'},
                // {data: 'aksi', searchable: false, sortable: false},
            ],
            columnDefs: [
                { targets: [3], type: 'data-range' , filterOptions: {
                    dateFormat: 'yyyy-mm-dd',
                    autoApply: true
                }}
            ]
        });

        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true
        });

        $('#filter-btn').on('click', function() {
            if ($('#tanggal_awal').val() > $('#tanggal_akhir').val()) {
                alert('Tanggal selesai awal tidak boleh lebih besar dari tanggal selesai akhir');
                return;
            }
            table.draw();
        });

        $('#pegawai').on('change', function() {
            if ($('#pegawai').val() != '' && $('#tanggal_awal').val() != '' && $('#tanggal_akhir').val() != '') {
                $('#cetak').removeAttr('disabled');
            }
            $('#_pegawai').val($(this).val());
        });

        $('#tanggal_awal').on('change', function() {
            if ($('#pegawai').val() != '' && $('#tanggal_awal').val() != '' && $('#tanggal_akhir').val() != '') {
                $('#cetak').removeAttr('disabled');
            }
            $('#_tanggal_awal').val($(this).val());
        });

        $('#tanggal_akhir').on('change', function() {
            if ($('#pegawai').val() != '' && $('#tanggal_awal').val() != '' && $('#tanggal_akhir').val() != '') {
                $('#cetak').removeAttr('disabled');
            }
            $('#_tanggal_akhir').val($(this).val());
        });

        $('#modal-form').validator().on('submit', function (e) {
            if (! e.preventDefault()) {
                $.post($('#modal-form form').attr('action'), $('#modal-form form').serialize())
                    .done((response) => {
                        $('#modal-form').modal('hide');
                        table.ajax.reload();
                    })
                    .fail((errors) => {
                        alert('Tidak dapat menyimpan data');
                        return;
                    });
            }
        });
    });

    // function addForm(url) {
    //     $('#modal-form').modal('show');
    //     $('#modal-form .modal-title').text('Tambah Kategori');

    //     $('#modal-form form')[0].reset();
    //     $('#modal-form form').attr('action', url);
    //     $('#modal-form [name=_method]').val('post');
    //     $('#modal-form [name=nama_kategori]').focus();
    // }

    // function editForm(url) {
    //     $('#modal-form').modal('show');
    //     $('#modal-form .modal-title').text('Edit PO');
    //     // echo "tes"; exit();


    //     $('#modal-form form').attr('action', url);
    //     $('#modal-form [name=_method]').val('put');
    //     $('#modal-form [name=kode_po]').focus();


    //     $.get(url)
    //         .done((response) => {
    //             $('#modal-form [name=kode_po]').val(response.kode_po);
    //     // $('#modal-form [name=id_statuses]').val(response.id_statuses);
    //     // $('#modal-form [name=id_user]').val(response.nama);
    //     // $('#modal-form [name=start_date]').val(response.start_date);
    //     // $('#modal-form [name=end_date]').val(response.end_date);
    //     // $('#modal-form [name=assigne]').val(response.assigne);

    //         })
    //         .fail((errors) => {
    //             alert('Tidak dapat menampilkan data');
    //             return;
    //         });
    // }

    // function deleteData(url) {
    //     if (confirm('Yakin ingin menghapus data terpilih?')) {
    //         $.post(url, {
    //                 '_token': $('[name=csrf-token]').attr('content'),
    //                 '_method': 'delete'
    //             })
    //             .done((response) => {
    //                 alert('Berhasil Menghapus Data')
    //                 table.ajax.reload();
    //             })
    //             .fail((errors) => {
    //                 alert('Tidak dapat menghapus data');
    //                 return;
    //             });
    //     }
    // }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TUGAS CORONA\semester 7\Pra skripso\TA_FAJAR_WEB\resources\views/gaji/index.blade.php ENDPATH**/ ?>